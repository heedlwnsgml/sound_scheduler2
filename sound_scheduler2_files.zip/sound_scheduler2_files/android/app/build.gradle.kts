plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.example.sound_scheduler2"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

//    compileOptions {
//        isCoreLibraryDesugaringEnabled = true
//        // 여기를 17로 변경
//        sourceCompatibility = JavaVersion.VERSION_17
//        targetCompatibility = JavaVersion.VERSION_17
//    }
//
//    kotlinOptions {
//        // 여기도 17로 변경 (문자열 "17" 사용)
//        jvmTarget = "17"
//    }

    compileOptions {
        // [수정됨] Kotlin DSL 문법 적용
        isCoreLibraryDesugaringEnabled = true

        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        applicationId = "com.example.sound_scheduler2"
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

flutter {
    source = "../.."
}

// [수정됨] Kotlin DSL 문법 적용 (괄호와 쌍따옴표 사용)
dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
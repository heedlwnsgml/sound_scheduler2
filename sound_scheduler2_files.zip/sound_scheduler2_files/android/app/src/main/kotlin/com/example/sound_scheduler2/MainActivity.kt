package com.example.sound_scheduler2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
